// src/routes/auth.js
import { Router } from "express";
import { validate } from "../middleware/validatePayload.js";
import Joi from "joi";
import {
  registerUser,
  confirmEmail,
  loginUser,
  refreshToken,
  requestPasswordReset,
  resetPassword
} from "../services/authService.js";

const router = Router();

// Validation schemas
const registerSchema = Joi.object({
  nome: Joi.string().required(),
  sobrenome: Joi.string().required(),
  email: Joi.string().email().required(),
  senha: Joi.string().required(),
  telefone: Joi.string().optional(),
  pais: Joi.string().optional()
});
const confirmEmailSchema = Joi.object({
  token: Joi.string().required()
});
const loginSchema = Joi.object({
  email: Joi.string().email().required(),
  senha: Joi.string().required()
});
const refreshSchema = Joi.object({
  token: Joi.string().required()
});
const requestResetSchema = Joi.object({
  email: Joi.string().email().required()
});
const confirmResetSchema = Joi.object({
  token: Joi.string().required(),
  newPassword: Joi.string().required()
});

// Routes
router.post(
  "/register",
  validate(registerSchema),
  async (req, res, next) => {
    try {
      const user = await registerUser(req.body);
      res.status(201).json(user);
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  "/confirm-email",
  validate(confirmEmailSchema),
  async (req, res, next) => {
    try {
      await confirmEmail(req.body.token);
      res.json({ success: true });
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  "/login",
  validate(loginSchema),
  async (req, res, next) => {
    try {
      const tokens = await loginUser(req.body);
      res.json(tokens);
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  "/refresh",
  validate(refreshSchema),
  async (req, res, next) => {
    try {
      const token = await refreshToken(req.body);
      res.json(token);
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  "/reset-password",
  validate(requestResetSchema),
  async (req, res, next) => {
    try {
      const ok = await requestPasswordReset(req.body);
      res.json(ok);
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  "/confirm-reset",
  validate(confirmResetSchema),
  async (req, res, next) => {
    try {
      const ok = await resetPassword(req.body);
      res.json(ok);
    } catch (err) {
      next(err);
    }
  }
);

export default router;
// src/routes/auth.js
import { Router } from "express";
import { validate } from "../middleware/validatePayload.js";
import Joi from "joi";
import {
  registerUser,
  confirmEmail,
  loginUser,
  refreshToken,
  requestPasswordReset,
  resetPassword
} from "../services/authService.js";

const router = Router();

// Validation schemas
const registerSchema = Joi.object({
  nome: Joi.string().required(),
  sobrenome: Joi.string().required(),
  email: Joi.string().email().required(),
  senha: Joi.string().required(),
  telefone: Joi.string().optional(),
  pais: Joi.string().optional()
});
const confirmEmailSchema = Joi.object({
  token: Joi.string().required()
});
const loginSchema = Joi.object({
  email: Joi.string().email().required(),
  senha: Joi.string().required()
});
const refreshSchema = Joi.object({
  token: Joi.string().required()
});
const requestResetSchema = Joi.object({
  email: Joi.string().email().required()
});
const confirmResetSchema = Joi.object({
  token: Joi.string().required(),
  newPassword: Joi.string().required()
});

// Routes
router.post(
  "/register",
  validate(registerSchema),
  async (req, res, next) => {
    try {
      const user = await registerUser(req.body);
      res.status(201).json(user);
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  "/confirm-email",
  validate(confirmEmailSchema),
  async (req, res, next) => {
    try {
      await confirmEmail(req.body.token);
      res.json({ success: true });
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  "/login",
  validate(loginSchema),
  async (req, res, next) => {
    try {
      const tokens = await loginUser(req.body);
      res.json(tokens);
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  "/refresh",
  validate(refreshSchema),
  async (req, res, next) => {
    try {
      const token = await refreshToken(req.body);
      res.json(token);
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  "/reset-password",
  validate(requestResetSchema),
  async (req, res, next) => {
    try {
      const ok = await requestPasswordReset(req.body);
      res.json(ok);
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  "/confirm-reset",
  validate(confirmResetSchema),
  async (req, res, next) => {
    try {
      const ok = await resetPassword(req.body);
      res.json(ok);
    } catch (err) {
      next(err);
    }
  }
);

export default router;
