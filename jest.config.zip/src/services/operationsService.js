// src/services/operationService.js
import { query } from './databaseService.js';

/**
 * Persiste uma operação
 * @param {Object} params
 * @param {number} params.user_id
 * @param {string} params.exchange
 * @param {string} params.operation_type
 * @param {string} params.symbol
 * @param {string} params.order_id
 * @param {number} params.qty
 * @param {number} params.price
 * @param {number} params.leverage
 * @param {number} params.pnl
 * @param {string} params.status
 * @param {string|Date} params.opened_at
 * @param {string|Date} params.closed_at
 * @returns {Promise<Object>} { id }
 */
export async function saveOperation({
  user_id,
  exchange,
  operation_type,
  symbol,
  order_id,
  qty,
  price,
  leverage,
  pnl,
  status,
  opened_at,
  closed_at
}) {
  const sql = `
    INSERT INTO operations (
      user_id,
      exchange,
      operation_type,
      symbol,
      order_id,
      qty,
      price,
      leverage,
      pnl,
      status,
      opened_at,
      closed_at
    ) VALUES (
      $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12
    )
    RETURNING id;
  `;
  const params = [
    user_id,
    exchange,
    operation_type,
    symbol,
    order_id,
    qty,
    price,
    leverage,
    pnl,
    status,
    opened_at,
    closed_at
  ];
  const result = await query(sql, params);
  return result.rows[0];
}

/**
 * Recupera operações de um usuário
 * @param {number} user_id
 * @param {number} [limit=50]
 * @returns {Promise<Array>}
 */
export async function getOperationsByUser(user_id, limit = 50) {
  const sql = `
    SELECT *
      FROM operations
     WHERE user_id = $1
     ORDER BY opened_at DESC
     LIMIT $2;
  `;
  const result = await query(sql, [user_id, limit]);
  return result.rows;
}
