// backend/src/index.js

import dotenv from "dotenv";

// 1️⃣ Escolhe qual arquivo de variáveis usar:
//    - Se NODE_ENV estiver igual a "testnet", carrega .env.testnet
//    - Caso contrário, carrega o .env padrão (produção)
const envFile =
  process.env.NODE_ENV === "testnet" || process.env.ENV_MODE === "testnet"
    ? ".env.testnet"
    : ".env";

dotenv.config({ path: envFile });
console.log(`🔧 Carregando variáveis de ${envFile}`);

import express from "express";
import cors from "cors";
import morgan from "morgan";
import bodyParser from "body-parser";

import * as dbMigrations from "./services/dbMigrations.js";
import { setupScheduler } from "./services/scheduler.js";

// Rotas
import webhookRouter from "./routes/webhookRoutes.js";
import fetchRouter from "./routes/fetch.js";
import tradingRouter from "./routes/trading.js";
import dashboardRouter from "./routes/dashboard.js";
import userRouter from "./routes/user.js";
import adminRouter from "./routes/admin.js";
import stripeRoutes, {
  stripeWebhookHandler,
} from "./routes/stripeRoutes.js";
import affiliateRouter from "./routes/affiliate.js";

const app = express();
const port = process.env.PORT || 8080;

// 2️⃣ CORS — ajuste em produção para sua URL real
app.use(
  cors({
    origin: "*", // em prod use o front: e.g. ["https://suafront.com"]
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  })
);
app.use(morgan("combined"));

// 3️⃣ Stripe Webhook precisa do raw body antes do JSON
app.post(
  "/api/stripe/webhook",
  bodyParser.raw({ type: "application/json" }),
  stripeWebhookHandler
);

// 4️⃣ parser JSON para todas as outras requisições
app.use(express.json({ limit: "500kb" }));

// Health-check
app.get("/", (_req, res) => res.send("🚀 Bot ativo!"));
app.get("/healthz", (_req, res) => res.send("OK"));

// 5️⃣ Executa todas as migrações automaticamente
(async () => {
  for (const [name, fn] of Object.entries(dbMigrations)) {
    if (typeof fn === "function" && name.startsWith("ensure")) {
      console.log(`🛠️ Rodando migração: ${name}`);
      await fn();
    }
  }

  // 6️⃣ Monta as rotas
  app.use("/webhook", webhookRouter);
  app.use("/api/fetch", fetchRouter);
  app.use("/api/trading", tradingRouter);
  app.use("/api/dashboard", dashboardRouter);
  app.use("/api/user", userRouter);
  app.use("/api/admin", adminRouter);
  app.use("/api/stripe", stripeRoutes);
  app.use("/api/affiliate", affiliateRouter);

  // 7️⃣ Inicia o servidor
  app.listen(port, () => {
    console.log(`🚀 Server listening on port ${port}`);
    setupScheduler();
  });
})();
